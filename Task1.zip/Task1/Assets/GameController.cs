﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public void GetInput(string input)
    {
        // putting the input string in a string array
        string[] text = input.Split(' ');
        Debug.Log("You entered: "+input);

        // printing the strings which hs odd number of characters.
        for (int i=0; i<text.Length; i++)
        {
            int len = text[i].Length;
            if ((len % 2) == 1)
            {
                Debug.Log(text[i]);
            }
        }
       
    }
}
