﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Tilemaps;


public class TiledMap : MonoBehaviour
{
     float X, Y, Z;
     public List<TileSprites> tileSprite = new List<TileSprites>();

    public void Awake()
    {
        // creating list of all the tiles
        tileSprite.Add(new TileSprites("WW", "Water", "water_01 Var"));
        tileSprite.Add(new TileSprites("GH", "Wall", "highground_01 Var"));
        tileSprite.Add(new TileSprites("GG", "Grass", "grass_01 Var"));
        tileSprite.Add(new TileSprites("DD", "Dirt", "dirt_01 Var"));

        // call the function to load map
        LoadMapData();
    }

    // funtion to read map data from input text file and place tiles
    public void LoadMapData()
    {
        string input = File.ReadAllText(Application.dataPath + "/Resources/map.txt");
        string[] f = input.Split(new string[] { "\n", "\r", "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
        X = -14;
        Y = -5;
        Z = 5;

        int i = 0, j = 0;
        foreach (var row in input.Split('$'))
        {
            Z = 5;
            foreach (var col in row.Trim().Split(':'))
            {
                if (col != "")
                {
                    string tagM = col;
                    SetTile(tagM, X, Y, Z);
                    Z = Z + 2;
                }
                j++;
            }
            X = X + 2;
            i++;
        }
    }


    // function to select specific tile from list and place it properly
    public void SetTile(string tag, float xx, float yy, float zz)
    {
        foreach (TileSprites tile in tileSprite)
        {
            int index = tileSprite.FindIndex(x => x.Tag.Equals(tag));
            tileSprite[index].PlaceTile(xx, yy, zz);
        }
    }

    // tiles class with place tiles method
    public class TileSprites 
    {

        public string Name;
        public string Tag;
        public string PfName;
        public GameObject Obj;
        public Transform target;


        public TileSprites(string tag, string name, string pfName)
        {
            Tag = tag;
            Name = name;
            PfName = pfName;
            Obj = Resources.Load(pfName) as GameObject;
        }

        public void PlaceTile(float x, float y, float z)
        {
            Obj.transform.position = new Vector3(x, y, z);
            Instantiate(Obj);
        }

    }

}
