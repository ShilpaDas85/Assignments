﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCube : MonoBehaviour
{
    public float speed = 10f;
    public Color color = Color.black;
    public Animation anim;
    Animator animator;
    float distance = 0.1f;

    public Vector3 RotateAmount;
    private IEnumerator coroutine;
    private IEnumerator coroutineSecond;

    // IEnumerator for moving and rotating cube
    IEnumerator MoveAndRotate(Transform _transform, Quaternion _rotation)
    {
        Vector3 startPos = _transform.position;
        if (Input.GetKeyDown(KeyCode.S))
        {
            Quaternion targetRotation = _rotation;
            targetRotation *= Quaternion.AngleAxis(90, Vector3.right);
            _transform.rotation = Quaternion.RotateTowards(_transform.rotation, targetRotation, speed);
            Vector3 endPos = new Vector3(startPos.x, startPos.y, startPos.z + distance);
            _transform.position = Vector3.Lerp(startPos, endPos, speed);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            Quaternion targetRotation = _rotation;
            targetRotation *= Quaternion.AngleAxis(90, Vector3.up);
            _transform.rotation = Quaternion.RotateTowards(_transform.rotation, targetRotation, speed);
            Vector3 endPos = new Vector3(startPos.x - distance, startPos.y , startPos.z);
            _transform.position = Vector3.Lerp(startPos, endPos, speed);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            Quaternion targetRotation = _rotation;
            targetRotation *= Quaternion.AngleAxis(90, Vector3.down);
            _transform.rotation = Quaternion.RotateTowards(_transform.rotation, targetRotation, speed);
            Vector3 endPos = new Vector3(startPos.x + distance, startPos.y, startPos.z);
            _transform.position = Vector3.Lerp(startPos, endPos, speed);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Quaternion targetRotation = _rotation;
            targetRotation *= Quaternion.AngleAxis(90, Vector3.left);
            _transform.rotation = Quaternion.RotateTowards(_transform.rotation, targetRotation, speed);
            Vector3 endPos = new Vector3(startPos.x , startPos.y, startPos.z - distance);
            _transform.position = Vector3.Lerp(startPos, endPos, speed);
        }

        yield return 0;
    }

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animation>();
        gameObject.GetComponent<Renderer>().material.color = Color.green;
    }

    // Update is called once per frame
    void Update()
    {
        Quaternion originalRotation = this.transform.rotation;

        // starting coroutine to move and rotate the cube
        coroutineSecond = MoveAndRotate(transform, originalRotation);
        StartCoroutine(coroutineSecond);
    }
}